-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 09-01-2024 a las 17:56:06
-- Versión del servidor: 10.4.27-MariaDB
-- Versión de PHP: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `facultad`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alumno`
--

CREATE TABLE `alumno` (
  `idAlumno` char(5) NOT NULL,
  `NIF` char(9) DEFAULT NULL,
  `nombre` tinytext NOT NULL,
  `apellido1` tinytext NOT NULL,
  `apellido2` tinytext DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `direccion` varchar(100) NOT NULL,
  `codigoPostal` decimal(5,0) NOT NULL,
  `municipio` tinytext NOT NULL,
  `provincia` tinytext NOT NULL,
  `beca` char(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `asignatura`
--

CREATE TABLE `asignatura` (
  `curso` decimal(2,0) NOT NULL,
  `idAsignatura` char(5) NOT NULL,
  `nombre` varchar(150) DEFAULT NULL,
  `cuatrimestre` enum('1','2') DEFAULT NULL,
  `creditos` double NOT NULL,
  `caracter` enum('obligatoria','optativa') NOT NULL,
  `coordinador` char(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `curso`
--

CREATE TABLE `curso` (
  `idCurso` decimal(2,0) NOT NULL,
  `nombreDescriptivo` tinytext NOT NULL,
  `nAsignaturas` decimal(3,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `curso`
--

INSERT INTO `curso` (`idCurso`, `nombreDescriptivo`, `nAsignaturas`) VALUES
('1', 'Primero', '10'),
('2', 'Segundo', '10'),
('3', 'Terceo', '10'),
('4', 'Cuarto', '53'),
('5', 'Master', '11'),
('6', 'Doctorado', '6');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `impartir`
--

CREATE TABLE `impartir` (
  `idProfesor` char(5) NOT NULL,
  `idAsignatura` char(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `matricula`
--

CREATE TABLE `matricula` (
  `idAlumno` char(5) NOT NULL,
  `idAsignatura` char(5) NOT NULL,
  `nota` double NOT NULL
) ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `profesor`
--

CREATE TABLE `profesor` (
  `idProfesor` char(5) NOT NULL,
  `NIF` char(9) DEFAULT NULL,
  `nombre` varchar(50) NOT NULL,
  `apellido1` varchar(50) NOT NULL,
  `apellido2` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `direccion` varchar(100) NOT NULL,
  `codigoPostal` decimal(5,0) NOT NULL,
  `municipio` tinytext NOT NULL,
  `provincia` tinytext NOT NULL,
  `categoria` enum('Catedráticos de Universidad','Titulares Universidad','Catedráticos de Escuela Universitaria','Titulares de Escuela Universitaria','Eméritos','Contratados Doctores','Contratados Doctores Interinos','Asociados','Asociado Interino','Ayudantes Doctores','Otros Investigadores Doctores','PDI predoctoral') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `profesor`
--

INSERT INTO `profesor` (`idProfesor`, `NIF`, `nombre`, `apellido1`, `apellido2`, `email`, `direccion`, `codigoPostal`, `municipio`, `provincia`, `categoria`) VALUES
('PR001', '34417139B', 'Juan', 'Infante', 'Fraidias', 'juan.infante.fraidias@ucm.com', 'Calle de los Almendros , 86', '28070', 'Las Rozas', 'Madrid', 'Asociados'),
('PR002', '52479077P', 'David', 'Serna', 'Balmori', 'david.serna.balmori@ucm.com', 'Calle Abarejo , 44', '28017', 'Brea de Tajo', 'Madrid', 'Titulares Universidad'),
('PR003', '84277383X', 'Josefa', 'Pedraza', 'Travez', 'josefa.pedraza.travez@ucm.com', 'Calle Abogados de Atocha , 145', '28035', 'El Molar', 'Madrid', 'Contratados Doctores'),
('PR004', '72702217A', 'Jose Antonio', 'Belda', 'Leno', 'jose.antonio.belda.leno@ucm.com', 'Calle de Ayamonte , 186', '28080', 'Pezuela de las Torres', 'Madrid', 'Titulares Universidad'),
('PR005', '75239553F', 'Jose Luis', 'Barragan', 'Usategui', 'jose.luis.barragan.usategui@ucm.com', 'Travesia del Almendro , 97', '28038', 'Robledillo de la Jara', 'Madrid', 'Catedráticos de Escuela Universitaria'),
('PR006', '81953461Y', 'Francisco Javier', 'Reig', 'Amills', 'francisco.javier.reig.amills@ucm.com', 'Calle de la Albericia , 134', '28071', 'Colmenarejo', 'Madrid', 'Contratados Doctores Interinos'),
('PR007', '18598553N', 'Ana Maria', 'De Diego', 'Bocigas', 'ana.maria.de.diego.bocigas@ucm.com', 'Avenida de los Andes , 188', '28030', 'Prádena del Rincón', 'Madrid', 'PDI predoctoral'),
('PR008', '72252271H', 'Carlos', 'Fuertes', 'Carulla', 'carlos.fuertes.carulla@ucm.com', 'Calle Águeda , 26', '28046', 'Velilla de San Antonio', 'Madrid', 'Catedráticos de Escuela Universitaria'),
('PR009', '70631063C', 'Daniel', 'Aguado', 'Pastrana', 'daniel.aguado.pastrana@ucm.com', 'Calle de Antoñita Jiménez , 122', '28041', 'Talamanca de Jarama', 'Madrid', 'Catedráticos de Universidad'),
('PR010', '15794042W', 'Maria Dolores', 'Espino', 'Zamudio', 'maria.dolores.espino.zamudio@ucm.com', 'Calle del Arroyo de la Elipa , 189', '28034', 'San Martín de la Vega', 'Madrid', 'Titulares Universidad'),
('PR011', '86245635W', 'Maria Pilar', 'Valderrama', 'Urquiaga', 'maria.pilar.valderrama.urquiaga@ucm.com', 'Calle Alisios , 150', '28006', 'Chapinería', 'Madrid', 'Catedráticos de Escuela Universitaria'),
('PR012', '83153833C', 'Miguel', 'Fuentes', 'Andreu', 'miguel.fuentes.andreu@ucm.com', 'Calle de la Alcoholera , 12', '28080', 'Pozuelo del Rey', 'Madrid', 'Contratados Doctores Interinos'),
('PR013', '55710808P', 'Maria Teresa', 'Pico', 'Zoyo', 'maria.teresa.pico.zoyo@ucm.com', 'Calle de Arenas de Iguña , 17', '28080', 'Algete', 'Madrid', 'Ayudantes Doctores'),
('PR014', '52041463T', 'Ana', 'Andujar', 'Popovici', 'ana.andujar.popovici@ucm.com', 'Calle de las Aguas , 61', '28035', 'Cabanillas de la Sierra', 'Madrid', 'Otros Investigadores Doctores'),
('PR015', '81703794T', 'Rafael', 'Murcia', 'Petrov', 'rafael.murcia.petrov@ucm.com', 'Calle Almendro , 53', '28012', 'Tielmes', 'Madrid', 'PDI predoctoral'),
('PR016', '36742399V', 'Jose Manuel', 'Antolin', 'Diranzo', 'jose.manuel.antolin.diranzo@ucm.com', 'Calle Azabache , 190', '28012', 'Piñuécar-Gandullas', 'Madrid', 'Catedráticos de Universidad'),
('PR017', '33150418J', 'Pedro', 'Calderon', 'Domenech', 'pedro.calderon.domenech@ucm.com', 'Carretera de Alpedrete , 104', '28008', 'Ciempozuelos', 'Madrid', 'Contratados Doctores'),
('PR018', '82285639Q', 'Laura', 'Bueno', 'Sobreira', 'laura.bueno.sobreira@ucm.com', 'Calle de los Árboles , 198', '28039', 'Cabanillas de la Sierra', 'Madrid', 'Catedráticos de Escuela Universitaria'),
('PR019', '37497894I', 'Francisca', 'Smith', 'Mafla', 'francisca.smith.mafla@ucm.com', 'Calle del Arco , 149', '28029', 'Moralzarzal', 'Madrid', 'Otros Investigadores Doctores'),
('PR020', '34744580Y', 'Antonia', 'Vara', 'Esarte', 'antonia.vara.esarte@ucm.com', 'Calle de Alba de Tormes , 123', '28030', 'Valdemoro', 'Madrid', 'Contratados Doctores'),
('PR021', '25542059S', 'Alejandro', 'Piã‘A', 'Ivars', 'alejandro.piã‘a.ivars@ucm.com', 'Calle Alfonso X El Sabio , 199', '28008', 'Colmenar de Oreja', 'Madrid', 'Catedráticos de Escuela Universitaria'),
('PR022', '71976482V', 'Dolores', 'Amoros', 'Cases', 'dolores.amoros.cases@ucm.com', 'Calle de las Acacias , 109', '28048', 'Manzanares el Real', 'Madrid', 'Catedráticos de Universidad'),
('PR023', '76471428I', 'Antonio', 'Quero', 'Atienza', 'antonio.quero.atienza@ucm.com', 'Vereda de las Arboledas , 89', '28015', 'Sevilla la Nueva', 'Madrid', 'Catedráticos de Universidad'),
('PR024', '57354131X', 'Jose', 'Valera', 'Bardal', 'jose.valera.bardal@ucm.com', 'Calle de la Alegría , 82', '28034', 'Villa del Prado', 'Madrid', 'Titulares Universidad'),
('PR025', '21841380T', 'Maria Carmen', 'Palacios', 'Cholvi', 'maria.carmen.palacios.cholvi@ucm.com', 'Calle Apolo , 32', '28083', 'Meco', 'Madrid', 'Otros Investigadores Doctores');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tlfcontactoprof`
--

CREATE TABLE `tlfcontactoprof` (
  `idProfesor` char(5) NOT NULL,
  `telefono` decimal(9,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `alumno`
--
ALTER TABLE `alumno`
  ADD PRIMARY KEY (`idAlumno`),
  ADD UNIQUE KEY `NIF` (`NIF`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indices de la tabla `asignatura`
--
ALTER TABLE `asignatura`
  ADD PRIMARY KEY (`idAsignatura`),
  ADD UNIQUE KEY `nombre` (`nombre`),
  ADD KEY `curso` (`curso`),
  ADD KEY `coordinador` (`coordinador`);

--
-- Indices de la tabla `curso`
--
ALTER TABLE `curso`
  ADD PRIMARY KEY (`idCurso`);

--
-- Indices de la tabla `impartir`
--
ALTER TABLE `impartir`
  ADD KEY `idProfesor` (`idProfesor`),
  ADD KEY `idAsignatura` (`idAsignatura`);

--
-- Indices de la tabla `matricula`
--
ALTER TABLE `matricula`
  ADD KEY `idAlumno` (`idAlumno`),
  ADD KEY `idAsignatura` (`idAsignatura`);

--
-- Indices de la tabla `profesor`
--
ALTER TABLE `profesor`
  ADD PRIMARY KEY (`idProfesor`),
  ADD UNIQUE KEY `NIF` (`NIF`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indices de la tabla `tlfcontactoprof`
--
ALTER TABLE `tlfcontactoprof`
  ADD KEY `idProfesor` (`idProfesor`);

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `asignatura`
--
ALTER TABLE `asignatura`
  ADD CONSTRAINT `asignatura_ibfk_1` FOREIGN KEY (`curso`) REFERENCES `curso` (`idCurso`),
  ADD CONSTRAINT `asignatura_ibfk_2` FOREIGN KEY (`coordinador`) REFERENCES `profesor` (`idProfesor`);

--
-- Filtros para la tabla `impartir`
--
ALTER TABLE `impartir`
  ADD CONSTRAINT `impartir_ibfk_1` FOREIGN KEY (`idProfesor`) REFERENCES `profesor` (`idProfesor`),
  ADD CONSTRAINT `impartir_ibfk_2` FOREIGN KEY (`idAsignatura`) REFERENCES `asignatura` (`idAsignatura`);

--
-- Filtros para la tabla `matricula`
--
ALTER TABLE `matricula`
  ADD CONSTRAINT `matricula_ibfk_1` FOREIGN KEY (`idAlumno`) REFERENCES `alumno` (`idAlumno`),
  ADD CONSTRAINT `matricula_ibfk_2` FOREIGN KEY (`idAsignatura`) REFERENCES `asignatura` (`idAsignatura`);

--
-- Filtros para la tabla `tlfcontactoprof`
--
ALTER TABLE `tlfcontactoprof`
  ADD CONSTRAINT `tlfcontactoprof_ibfk_1` FOREIGN KEY (`idProfesor`) REFERENCES `profesor` (`idProfesor`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
